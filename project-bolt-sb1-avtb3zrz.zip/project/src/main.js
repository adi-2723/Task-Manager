// Task Manager functionality
class TaskManager {
  constructor() {
    this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    this.currentFilter = 'all';
    this.init();
  }

  init() {
    // DOM Elements
    this.taskForm = document.getElementById('task-form');
    this.taskInput = document.getElementById('task-input');
    this.taskPriority = document.getElementById('task-priority');
    this.tasksList = document.getElementById('tasks-list');
    this.tasksCount = document.getElementById('tasks-count');
    this.clearCompletedBtn = document.getElementById('clear-completed');
    this.filterButtons = document.querySelectorAll('.filter-btn');

    // Event Listeners
    this.taskForm.addEventListener('submit', (e) => this.handleSubmit(e));
    this.clearCompletedBtn.addEventListener('click', () => this.clearCompleted());
    this.filterButtons.forEach(btn => {
      btn.addEventListener('click', () => this.setFilter(btn.dataset.filter));
    });

    // Initial render
    this.render();
  }

  handleSubmit(e) {
    e.preventDefault();
    const text = this.taskInput.value.trim();
    const priority = this.taskPriority.value;

    if (text) {
      this.addTask(text, priority);
      this.taskInput.value = '';
      this.render();
    }
  }

  addTask(text, priority) {
    const task = {
      id: Date.now().toString(),
      text,
      priority,
      completed: false,
      createdAt: new Date()
    };

    this.tasks.unshift(task);
    this.saveTasks();
  }

  toggleTask(id) {
    const task = this.tasks.find(t => t.id === id);
    if (task) {
      task.completed = !task.completed;
      this.saveTasks();
      this.render();
    }
  }

  deleteTask(id) {
    this.tasks = this.tasks.filter(task => task.id !== id);
    this.saveTasks();
    this.render();
  }

  clearCompleted() {
    this.tasks = this.tasks.filter(task => !task.completed);
    this.saveTasks();
    this.render();
  }

  setFilter(filter) {
    this.currentFilter = filter;
    this.filterButtons.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.filter === filter);
    });
    this.render();
  }

  getFilteredTasks() {
    switch (this.currentFilter) {
      case 'active':
        return this.tasks.filter(task => !task.completed);
      case 'completed':
        return this.tasks.filter(task => task.completed);
      default:
        return this.tasks;
    }
  }

  saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(this.tasks));
  }

  render() {
    const filteredTasks = this.getFilteredTasks();
    this.tasksList.innerHTML = filteredTasks
      .map(task => this.createTaskElement(task))
      .join('');
    
    const activeTasks = this.tasks.filter(task => !task.completed).length;
    this.tasksCount.textContent = activeTasks;
  }

  createTaskElement(task) {
    return `
      <div class="task-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
        <input
          type="checkbox"
          class="task-checkbox"
          ${task.completed ? 'checked' : ''}
          onchange="taskManager.toggleTask('${task.id}')"
        >
        <div class="task-content">
          <p class="task-text">${this.escapeHtml(task.text)}</p>
          <span class="task-priority ${task.priority}">${task.priority}</span>
        </div>
        <button
          class="delete-btn"
          onclick="taskManager.deleteTask('${task.id}')"
        >
          ×
        </button>
      </div>
    `;
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
}

// Initialize the task manager
window.taskManager = new TaskManager();
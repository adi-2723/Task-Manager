import React, { useState, useEffect } from 'react';
import { Search, Cloud, Droplets, Wind, Thermometer, MapPin } from 'lucide-react';
import './App.css';

interface WeatherData {
  main: {
    temp: number;
    humidity: number;
    feels_like: number;
  };
  weather: Array<{
    main: string;
    description: string;
  }>;
  wind: {
    speed: number;
  };
  name: string;
}

function App() {
  const [city, setCity] = useState('London');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const API_KEY = 'YOUR_API_KEY'; // Note: In production, use environment variables
  
  useEffect(() => {
    fetchWeather();
  }, []);

  const fetchWeather = async () => {
    try {
      setLoading(true);
      setError('');
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
      );
      if (!response.ok) {
        throw new Error('City not found');
      }
      const data = await response.json();
      setWeather(data);
    } catch (err) {
      setError('Failed to fetch weather data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchWeather();
  };

  const getBackgroundImage = () => {
    if (!weather) return 'https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?auto=format&fit=crop&w=2070&q=80';
    const condition = weather.weather[0].main.toLowerCase();
    const images = {
      clear: 'https://images.unsplash.com/photo-1601297183305-6df142704ea2?auto=format&fit=crop&w=2070&q=80',
      clouds: 'https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&w=2070&q=80',
      rain: 'https://images.unsplash.com/photo-1519692933481-e162a57d6721?auto=format&fit=crop&w=2070&q=80',
      snow: 'https://images.unsplash.com/photo-1478265409131-1f65c88f965c?auto=format&fit=crop&w=2070&q=80',
    };
    return images[condition as keyof typeof images] || images.clear;
  };

  return (
    <div 
      className="app-container"
      style={{ backgroundImage: `url(${getBackgroundImage()})` }}
    >
      <div className="overlay">
        <div className="content">
          <form onSubmit={handleSubmit} className="search-form">
            <div className="search-container">
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Enter city name..."
                className="search-input"
              />
              <Search className="search-icon" size={20} />
              <button type="submit" className="search-button">
                Search
              </button>
            </div>
          </form>

          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {loading ? (
            <div className="loading-message">Loading...</div>
          ) : weather ? (
            <div className="weather-card">
              <div className="weather-header">
                <div className="city-info">
                  <h1>
                    <MapPin />
                    {weather.name}
                  </h1>
                  <p className="weather-description">{weather.weather[0].description}</p>
                </div>
                <div className="temperature">
                  {Math.round(weather.main.temp)}°C
                </div>
              </div>

              <div className="weather-details">
                <div className="weather-detail-card">
                  <Thermometer size={24} />
                  <div className="detail-info">
                    <p className="detail-label">Feels Like</p>
                    <p className="detail-value">{Math.round(weather.main.feels_like)}°C</p>
                  </div>
                </div>

                <div className="weather-detail-card">
                  <Droplets size={24} />
                  <div className="detail-info">
                    <p className="detail-label">Humidity</p>
                    <p className="detail-value">{weather.main.humidity}%</p>
                  </div>
                </div>

                <div className="weather-detail-card">
                  <Wind size={24} />
                  <div className="detail-info">
                    <p className="detail-label">Wind Speed</p>
                    <p className="detail-value">{weather.wind.speed} m/s</p>
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}

export default App;